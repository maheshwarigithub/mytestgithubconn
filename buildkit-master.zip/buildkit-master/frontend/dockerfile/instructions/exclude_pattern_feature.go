//go:build dfexcludepatterns
// +build dfexcludepatterns

package instructions

func init() {
	excludePatternsEnabled = true
}
