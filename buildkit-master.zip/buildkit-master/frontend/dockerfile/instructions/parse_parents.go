//go:build dfparents
// +build dfparents

package instructions

func init() {
	parentsEnabled = true
}
