# Dockerfile frontend syntaxes

This page has moved to [Dockerfile reference documentation](reference.md)
