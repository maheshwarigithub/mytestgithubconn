package main

const (
	defaultContainerdAddress = "//./pipe/containerd-containerd"
)
