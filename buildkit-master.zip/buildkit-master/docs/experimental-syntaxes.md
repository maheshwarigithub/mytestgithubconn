# Dockerfile frontend syntaxes

This page has moved to [Dockerfile reference documentation](/frontend/dockerfile/docs/reference.md)
