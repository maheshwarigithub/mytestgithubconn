# Build information

Build information has been removed since BuildKit v0.12.0. See the [Deprecated features page](https://github.com/moby/buildkit/blob/master/docs/deprecated.md)
for status and alternative recommendation about this feature.
